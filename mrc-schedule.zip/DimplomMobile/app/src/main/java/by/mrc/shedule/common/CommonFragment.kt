package by.mrc.shedule.common

interface CommonFragment  {
}