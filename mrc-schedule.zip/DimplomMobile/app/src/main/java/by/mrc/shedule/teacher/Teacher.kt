package by.mrc.shedule.teacher

data class Teacher(
    val name: String,
    val surname: String,
    val patronymic: String,
    val phoneNumber: String,
    val description: String
)