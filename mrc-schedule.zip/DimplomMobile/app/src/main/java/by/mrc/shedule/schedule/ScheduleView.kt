package by.mrc.shedule.schedule

interface ScheduleView {

    fun renderSchedule(schedule: List<Schedule>)
}